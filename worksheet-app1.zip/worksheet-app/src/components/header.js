import React from "react";

class Header extends React.Component{
    render(){
        return(
          
           
                <div class="logo">
                      <img src={require("../logo.jpg")}  alt= "Logo"/>
                </div>
            
         
          

        )

    }
}

export default Header;