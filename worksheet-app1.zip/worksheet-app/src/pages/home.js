import React from "react";
import  { Link } from "react-router-dom";
import "./App.css";

class home extends React.Component{
        render(){
            return(
            <><h1>Welcome to Kids Worksheets!</h1><div class="options">
                    <a href="mathematics.html">Mathematics Worksheet</a>
                    <Link to="/mathematics">Mathematics worksheet</Link>
                    <a href="life orientation.html">Life Skills Worksheet</a>
                    <a href="vocabulary.html">Vocabulary Worksheet</a>
                </div></>
            );
            
               
            
        }
}

export default home;